#New PBE ground states as of 2022-11-01 (finalized since we won't be doing T- and TT-Nb2O5)
TiO_exp Ti2O-mp-1215_omega 0.0
TiO_exp TiO2-mp-554278_bronze-B 0.0
TiO_exp TiO-mp-1071163_epsilon 0.0


# All remaining GS's
NbO Nb12O29 0.0
NbO Nb22O54 0.0
NbO Nb2O5 0.0
NbO Nb3O7 0.0
NbO Nb_bcc 0.0
NbO NbO_orderedrs 0.0
NbO Nb25O62 0.0
TiO_FCC Ti2O3_FCC 0.0
magnelli Ti4O7_magnelli 0.0
TiO_HCP Ti3O_HCP 0.0
TiO_HCP Ti6O_HCP 0.0
TiO_HCP Ti_hcp 0.0
TiNb3O6 TiNb3O6 0.0
M3O7_casm Ti1Nb8O21 0.0
M3O7_casm Ti2Nb7O21 0.0
TixNb(12-x)O29 Ti2Nb10O29 0.0
TixNb(12-x)O29 TiNb11O29 0.0
O2_reference O2_reference 0.0



# Formerly ground states (2022-10-26) but now off hull (now with new hull dist)
TiO_FCC Ti5O5 0.04183210399999915
TiO_FCC Ti6O7 0.019276883076926765
TiO_HCP Ti3O2_8 0.03409037700000095
TiO_other_structs TiO2_anatase 0.005700257916670282

