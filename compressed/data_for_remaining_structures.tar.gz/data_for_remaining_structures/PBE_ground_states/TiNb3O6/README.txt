I think I messed up the mapping so this might not be FCC actually.

Also some of the Nb are have 5 oxygen neighbors so watch out in your code
